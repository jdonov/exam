package web.exam.model.entity;

public enum CategoryNames {
    FOOD, DRINK, HOUSEHOLD, OTHER;
}
